/*
6.18 
(Check password) Some websites impose certain rules for passwords. This program
* checks whether a string is a valid password. Suppose the password rules are as follows:
* A password must have at least eight characters.
* A password consists of only letters and digits.
* A password must contain at least two digits.
Write a program that prompts the user to enter a password and displays Valid
Password if the rules are followed or Invalid Password otherwise.
 */
import javax.swing.JOptionPane;

public class C6E18 {
	public static void main(String[]args) {		
		int option=JOptionPane.YES_OPTION;
		
		while (option == JOptionPane.YES_OPTION) {
			try {
				String password=JOptionPane.showInputDialog("This program checks whether a string is a valid password. \nEnter a password that has at least 8 letters and 2 must be digits");
				isValid(password);
				
				option = JOptionPane.showConfirmDialog(null, "Valid Password"+"\nDo you want to check another one?");
			}
			catch(Exception ex) {
				String outputStr = "Invalid passowrd: "+ ex.getMessage()+ "\nDo you want to check another one?";
				option = JOptionPane.showConfirmDialog(null, outputStr);
			}
		}
}

public static boolean isValid(String password) {

	boolean validPassword = 
		validLength(password) && 
		rightFormat(password) &&
		rightDigits(password);

	return validPassword;
}

public static boolean validLength(String password) {
	return password.length() >= 8;
}


public static boolean rightFormat(String password) {
	for (int i = 0; i < password.length(); i++) {
		if (!Character.isLetterOrDigit(password.charAt(i))) {
			return false;
		}
	}
	return true;
}


public static boolean rightDigits(String password) {
	int numberOfDigits = 0;
	for (int i = 0; i < password.length(); i++) {
		if (Character.isDigit(password.charAt(i))) {
			numberOfDigits++;
		}
		if (numberOfDigits >= 2) {
			return true;
		}
	}
	return false;
}
}
